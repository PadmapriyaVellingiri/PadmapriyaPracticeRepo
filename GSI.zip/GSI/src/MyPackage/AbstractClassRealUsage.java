package MyPackage;

/*
17.  Abstract Class + Real Usage

Create an abstract class Employee with:

abstract method: calculateSalary()

concrete method: employeeDetails()
Subclass FullTimeEmployee and PartTimeEmployee implementing salary calculation logic differently.

*/

abstract class Employee1
{
	String name;
	int empId;
	
	Employee1(String name, int empId)
	{
		this.name = name;
		this.empId = empId;
	}
	
	abstract void calculateSalary();
	
	void employeeDetails()
	{
		System.out.println("Employee Name : "+ name);
		System.out.println("Employee ID : "+ empId);
	}

}

class FullTimeEmployee extends Employee1
{
	int monthlySalary;
	
	FullTimeEmployee(String name, int empId, int monthlySalary)
	{
		super(name, empId);
		this.monthlySalary = monthlySalary;
		
	}
	
	@Override
	void calculateSalary() 
	{
		System.out.println("Full Time Salary : " + monthlySalary);
		System.out.println("  ");
		
	}
	
}

class PartTimeEmployee extends Employee1
{

	int hoursWorked;
	int hourlyRate;
	
	PartTimeEmployee(String name, int empId, int hoursWorked,int hourlyRate) 
	{
		super(name, empId);
		this.hoursWorked = hoursWorked;
		this.hourlyRate = hourlyRate;		
	}

	@Override
	void calculateSalary() 
	{
		int salary = hoursWorked * hourlyRate;
		System.out.println("Part time Employee : " + salary);
		
	}

	
}
public class AbstractClassRealUsage {

	public static void main(String[] args)
	{
		
		Employee1 e1 = new FullTimeEmployee("Jhon", 102,5000);
		e1.employeeDetails();
		e1.calculateSalary();
		
		Employee1 e2 = new PartTimeEmployee("smith", 40, 50, 500);
		e2.employeeDetails();
		e2.calculateSalary();

	}

}
