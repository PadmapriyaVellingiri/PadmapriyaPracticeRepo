package MyPackage;

/* 
WAP in Java
Create a class named Employee with private instance variables empId, empName, and salary.
Provide public getters and setters for all variables.
Create a method displayDetails() to print employee details.
Create an object in the main method and assign values using setters then display them.
 */

class Employee
{
	private int empId;
	private String empName;
	private int salary;
	
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public void displayDetails()
	{
		System.out.println("Employee ID : " + empId);
		System.out.println("Employee Name : " + empName);
		System.out.println("Salary : " + salary);
	}
	
}

public class EncapsulationGetterSetter {

	public static void main(String[] args) {
		
		Employee d =  new Employee();
		
		d.setEmpId(12345);
		d.setEmpName("Joo");
		d.setSalary(80000);
		
		d.displayDetails();
		
	}

}
