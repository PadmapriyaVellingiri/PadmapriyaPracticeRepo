package MyPackage;

/*
 22. Final Keyword + Constant

Create a class GovernmentRules with a final variable MAX_WORKING_HOURS = 8
Try modifying it inside main and observe compile-time restriction.

 */

class GovernmentRules
{
	final int maxWorkingHours = 8;
	
}

public class FinalKeywordConstant {

	public static void main(String[] args)
	{
		GovernmentRules rules = new GovernmentRules();
		System.out.println("Goverment rules for working hours is 8 ");
		
		rules.maxWorkingHours = 10;

	}

}
