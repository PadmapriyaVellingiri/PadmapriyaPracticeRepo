package MyPackage;

/*
 14. Hierarchical Inheritance

Create a class Course with a method courseInfo().
Create subclasses Science, Commerce, and Arts each with their own method.
Create objects of each and call methods to show hierarchy.
*/

class Course
{
	void courseInfo()
	{
		System.out.println("Course details");
	}
}

class Science extends Course
{
	void display()
	{
		System.out.println("This course contains Science subject");
	}
}

class Commerce extends Course
{
	void display()
	{
		System.out.println("This course contains commerce subject");
	}
}

class Arts extends Course
{
	void display()
	{
		System.out.println("This course contains arts subject");
	}
}

public class HierarchicalInheritance {

	public static void main(String[] args) 
	{
		Science sc = new Science();
		sc.courseInfo();
		sc.display();
		
		Commerce com = new Commerce();
		com.courseInfo();
		com.display();
		
		Arts arts = new Arts();
		arts.courseInfo();
		arts.display();
		
	}

}
