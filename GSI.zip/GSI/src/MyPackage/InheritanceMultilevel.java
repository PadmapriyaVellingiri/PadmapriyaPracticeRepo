package MyPackage;

/*
13. Inheritance (Multilevel)

Create three classes:

Device â†’ method start()

Mobile extends Device â†’ method calling()

SmartPhone extends Mobile â†’ method internet()
Create object of SmartPhone and call all methods.

 */


class Device
{
	void start()
	{
		System.out.println("Device ");
	}
}

class Mobile extends Device
{
	void calling()
	{
		System.out.println("Mobile ");
	}
}

class SmartPhone extends Mobile
{
	void internet()
	{
		System.out.println("SmartPhone");
	}
}

public class InheritanceMultilevel {

	public static void main(String[] args) {
		SmartPhone sp = new SmartPhone();
		
		sp.start();
		sp.calling();
		sp.internet();
		
	}

}
