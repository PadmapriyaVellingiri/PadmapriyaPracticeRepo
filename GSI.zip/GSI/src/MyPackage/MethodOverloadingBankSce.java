package MyPackage;

/*
  15.  Method Overloading (Bank Scenario)

Create a class LoanCalculator with two overloaded methods:

calculateLoan(int amount)

calculateLoan(int amount, double interestRate)
Print loan details accordingly. Call both methods from main.
*/
class LoanCalculator
{
	void calculateLoan(int amount)
	{
		System.out.println("Loan Amount       : " + amount);
        System.out.println("Interest Rate     : 10%");
        double totalAmount = amount + (amount * 0.10);
        System.out.println("Total Payable Amt : " + totalAmount);
        System.out.println();

	}
	
	void calculateLoan(int amount, double interestRate)
	{
        System.out.println("Loan Amount       : " + amount);
        System.out.println("Interest Rate     : " + interestRate + "%");
        double totalAmount = amount + (amount * interestRate / 100);
        System.out.println("Total Payable Amt : " + totalAmount);
        System.out.println();
	}
}

public class MethodOverloadingBankSce {

	public static void main(String[] args) {
		
		LoanCalculator l = new LoanCalculator();
		
		l.calculateLoan(50000);
		
		l.calculateLoan(90000, 5.5);
		
	}

}
