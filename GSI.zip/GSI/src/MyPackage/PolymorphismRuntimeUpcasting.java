package MyPackage;

/*
 19. Polymorphism (Runtime + Upcasting)

Create a class Camera with a method capture().
Create a subclass DSLCamera that overrides the method.
Use parent reference to call child object method (dynamic polymorphism).

 */

class Camera
{
	void capture()
	{
		System.out.println(" Camera is capturing a photo ");
	}
}

class DSLCamera extends Camera
{
	void capture()
	{
		System.out.println(" DSLCamera is capturing high quality photo ");
	}

}

public class PolymorphismRuntimeUpcasting {

	public static void main(String[] args) 
	{
		
		Camera cam = new DSLCamera();
		cam.capture();

	}

}
