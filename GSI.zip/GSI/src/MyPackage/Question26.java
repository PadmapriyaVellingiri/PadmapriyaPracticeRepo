package MyPackage;

/*
 
16>    WAP in Java to create a class named school 
create name, address,strength as their instance variables 
Create two constructor one with two variables and one with all the three variables 
Create a method that will display all the three parameters 
create two object of this class and call the respective methods 
 */

class School1
{
	String name;
	String address;
	int strength;
	
	School1(String i, String j)
	{
		name = i;
		address = j;
	}
	
	School1(String i, String j, int k)
	{
		name = i;
		address = j;
		strength = k;
	}
	void display()
	{
		System.out.println("School Name : " + name);
		System.out.println("School Address : " + address);
		System.out.println("School Strength : " + strength);
		System.out.println("  ");
	}
}

public class Question26 {

	public static void main(String[] args) 
	{
		School1 sch1 = new School1("Little Flower School", "Kolkata");
		
		School1 sch2 = new School1("Saru School", "Kolkata", 500);
		
		sch1.display();
		sch2.display();

	}

}
