package MyPackage;

/*
 21.  Static Concepts

Create a class University with:

static variable country = "India"

instance variable universityName
Print values using different objects to show static effect.

 */

class University
{
	static String country = "India" ;
	String universityName;
	
	void display(String n)
	{
		System.out.println("Country :" + country + " / " + "University name : " + n);
	}
	
}

public class StaticConcepts {

	public static void main(String[] args)
	{
		University u = new University();
		u.display("Bharathiyar university");
		
		University u1 = new University();
		u1.display("Anna university");

	}

}
