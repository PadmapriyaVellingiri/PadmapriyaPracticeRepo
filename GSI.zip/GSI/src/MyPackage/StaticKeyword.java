package MyPackage;

/*
 10.  Static Keyword

Create a class Student having static variable collegeName and instance variables name and rollNo.
Write a method to print both static and instance data.
Create multiple objects to show static value remains constant.

 */

class Student1
{
	static String collegeName = "ABC College";
	String name;
	int rollNo;
	
	Student1(String name, int rollNo)
	{
		this.name = name;
		this.rollNo = rollNo;
	}
	
	void display()
	{
		System.out.println("College Name : " + collegeName);
		System.out.println("Roll No : " + rollNo);
		System.out.println("Name : " + name);
		System.out.println("");	
	}
	
}

public class StaticKeyword {

	public static void main(String[] args) {
		
		Student1 s1 = new Student1("Jhon", 1001);
		Student1 s2 = new Student1("Smith", 1002);
		Student1 s3 = new Student1("Jack", 1003);
		
		s1.display();
		s2.display();
		s3.display();
		
		
		Student1.collegeName = "XYZ college";
		
		System.out.println("College Name Changed");
		System.out.println("");
		
		s1.display();
		s2.display();
		s3.display();
				
	}

}
