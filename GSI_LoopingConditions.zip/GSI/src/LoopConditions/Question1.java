package LoopConditions;

import java.io.DataInput;
import java.util.Scanner;

/*Write a Java program that prints "VALID" only if a number:
is divisible by 3
NOT divisible by 5
lies between 50 and 200 (inclusive)
Otherwise print "INVALID"
âž¡ï¸ Use only one if statement
 */

class A1
{
	static void print()
	{
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num = sc.nextInt();
		if (num >= 50 && num <= 200 && num % 3 == 0 && num % 5 != 0)
		{
			System.out.println("VALID");
		}	
		else
		{
		System.out.println("INVALID");
		}
		sc.close();
	}
}

public class Question1 {

	public static void main(String[] args) 
	{
		A1.print();		

	}

}
