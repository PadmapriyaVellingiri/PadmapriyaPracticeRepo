package LoopConditions;

import java.util.Scanner;
/*
 10.Input a number and check:

If it’s a 3-digit number

If yes, check whether the sum of digits is even or odd
➡️ Use nested if only

🔹 WHILE LOOP (Tricky Iterations)
 */

class A10
{
	static void run()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter a number : ");
		int num = sc.nextInt();
		if(num >= 100 && num <= 999 || num <= -100 && num >= -999)
		{
			int sum = 0;
			int temp = Math.abs(num);
			while(temp > 0)
			{
				int digit = temp%10;
				sum = sum + digit;
				temp = temp / 10; 
			}
			if(sum % 2 == 0 )
			{
				System.out.println("sum of digits :" + sum + " (Even)");
			}
			else
			{
				System.out.println("sum of digits :" + sum + " (Odd)");
			}
		}
		else
		{
			System.out.println("sum of digits is not a 3 digit number.");
		}
			sc.close();	
	}
}

public class Question10 {

	public static void main(String[] args) {
		
		A10.run();
	}

}
