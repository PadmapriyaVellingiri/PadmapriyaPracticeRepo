package LoopConditions;

/*
 11.Print numbers from 1 to 100 but:

Skip numbers divisible by both 3 and 5

Stop completely when number reaches 77
➡️ Use while only
 */

class A11
{
	static void run()
	{
		int i = 1;
		while(i <= 100 )
		{
			if(i%3 != 0 && i%5 != 0)
			{
				System.out.println(i);
			}
			if(i <= 77)
			{
			i++;
			}
			
		}
	}
}

public class Question11 {

	public static void main(String[] args) {
		
A11.run();
	}

}
