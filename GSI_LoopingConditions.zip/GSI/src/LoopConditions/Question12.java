package LoopConditions;

import java.util.Scanner;

/*
12.Write a program to reverse a number using while, but:

Stop reversing if digit 0 is encountered
 */

class A12
{
	static void run()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number to reverse : ");
		int num = sc.nextInt(); 
		int rev = 0; 
		while (num > 0)
		{
			int temp = num%10;
			rev = temp;
			num = num/10;	
			System.out.print(rev);
		}
	}
}

public class Question12 {

	public static void main(String[] args) {
		A12.run();
	}

}
