package LoopConditions;

import java.util.Scanner; 
/*
 13.Find the count of prime digits in a number using while loop only
 */

class A13
{
	static void run()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int num = sc.nextInt();
		System.out.print("Prime digits :");	
		int count =0;		
		while(num > 0)
		{
			int digit = num%10;
			if(digit ==2 || digit ==3 || digit ==5 || digit ==7)
			{
			System.out.print(digit +" ");
			count++;
			}
			num = num/10;
		}
		System.out.println(" ");
		System.out.println("Prime count is :" + count);
		
	}
}

public class Question13 {

	public static void main(String[] args) {
		A13.run();

	}

}
