package LoopConditions;

import java.util.Scanner;

/*14.Write a program that prints the Fibonacci series up to N terms, but:

Stop printing when a number exceeds 500
 */

class A14
{
	static void run()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number of terms : ");
		int n = sc.nextInt();
		int a = 0;
		int b = 1;
		int count = 0;
		
		while(count < n)
		{
			if(a>500)
			{
				break;
			}
			System.out.println(a + "  ");
			
			int next = a+b;
			a=b;
			b=next;
			count++;
		}
		sc.close();
		
	}
}

public class Question14 {

	public static void main(String[] args) {
		
		A14.run();
	}

}
