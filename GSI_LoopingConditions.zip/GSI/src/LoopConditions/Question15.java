package LoopConditions;

import java.util.Scanner;

/*15.Using while, print the following sequence:
1 2 4 7 11 16 22 ...
(up to N terms)
🔹 DO–WHILE LOOP (Edge Cases)
 */

class A15
{
	static void display()
	{
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a number : ");
	int n = sc.nextInt();//10
	int i = 1;
	int j = 0;
	int count = 1;
	while (count <= n)
	{
		if(count==n)
		{
			break;
		}
	int sum = i+j;
	System.out.print(sum + " ");
	i = sum ;
	j=count++;
	}
	
	
}
}

public class Question15 {

	public static void main(String[] args) 
	{
		
		A15.display();
	}
}