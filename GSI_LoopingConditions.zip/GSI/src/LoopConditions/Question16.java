package LoopConditions;

import java.util.Scanner;

/*
16.Write a program that:
Takes user input until a negative number is entered
Prints sum of all even numbers entered
➡️ Use do–while
 */

class A16
{
	static void run()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int num;
		int sum = 0;
		do 
		{
		num = sc.nextInt();
		if(num >= 0 && num%2 == 0)
		{
			sum = sum + num;
		}
		}while(num >=0);
		
		System.out.println("sum of all even numbers : " + sum);
		}
}

public class Question16 {

	public static void main(String[] args) {
		A16.run();

	}

}
