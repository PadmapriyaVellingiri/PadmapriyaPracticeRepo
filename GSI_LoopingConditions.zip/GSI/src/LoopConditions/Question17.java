package LoopConditions;

import java.util.Scanner;

/*17.Using do–while, print digits of a number from left to right
(No strings, no arrays)
*/

class A17
{
	static void display()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int num = sc.nextInt();
		int temp = num;
		int divisor = 1;
		while(temp >= 10)
		{
			temp = temp /10;
			divisor = divisor * 10;
		}
		do
		{
			int digit = num/divisor;
			System.out.print(digit);
			num = num % divisor;
			divisor = divisor/10;
		}while(divisor >= 1);		
	}
}

public class Question17 {

	public static void main(String[] args) {
		A17.display();

	}

}
