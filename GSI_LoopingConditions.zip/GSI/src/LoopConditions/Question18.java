package LoopConditions;

/*18.Write a program that executes at least once, even if condition is false, and prints:
Loop Executed
➡️ Modify condition logically
*/

class A18
{
	static void display()
	{
		int num = 0;
		do
		{
			System.out.println("Loop Executed");
		}while(num != 0);
	}
}

public class Question18 {

	public static void main(String[] args) {
		
		A18.display();

	}

}
