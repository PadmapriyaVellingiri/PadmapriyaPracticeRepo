package LoopConditions;

import java.util.Scanner;

/*
 19.Create a menu-driven program using do–while:

Add

Subtract

Multiply

Exit
 */

class A19
{
	static void menudriven()
	{
		Scanner sc = new Scanner(System.in);
		char ch;
		do
		{
		System.out.println("");
		System.out.println("Menu driven program");
		System.out.println("enter + or - or * or x to exit :");
		ch = sc.next().charAt(0);
		if(ch == 'x')
		{
			System.out.println("Exiting program");
			break;
		}
				
		System.out.println("Enter first number : ");
		int a = sc.nextInt();
		System.out.println("Enter second number : ");
		int b = sc.nextInt();
		int c ;
		
		if(ch == '+')
		{
			c = a+b;
			System.out.println("sum of 2 numbers : " + c);
			
		}
		else if(ch == '-')
		{
			c = a-b;
			System.out.println("diif od 2 umber is :" + c);
		}
		else if(ch == '*')
		{
			c = a*b;
			System.out.println("multiply of 2 number is :" + c);
		}
		else
		{
			System.out.println("Invalid");
		}
		}while(true);
		
	sc.close();
	}
}



public class Question19 {

	public static void main(String[] args) {
		A19.menudriven();

	}

}
