package LoopConditions;

import java.util.Scanner;

/*
2.Given three integers a, b, and c, print the second largest number using:
Only ifâ€“else
 */

class A2
{
	static void secondLargest()
	{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a value a : ");
		int a = sc.nextInt();
		System.out.println("Enter a value b : ");
		int b = sc.nextInt();
		System.out.println("Enter a value c: ");
		int c = sc.nextInt();
		
		if(a>b && a<c || a>c && a<b)
		{
			System.out.println(" A is second Largest : " + a);
		}
		else if(b>a && b<c || b>c && b<a)
		{
			System.out.println("B is the second largest : " + b);
		}
		else
		{
			System.out.println("C is the second largest : " + c);
		}
		
		sc.close();
	}
}

public class Question2 {

	public static void main(String[] args) 
	{
		A2.secondLargest();
	}

}
