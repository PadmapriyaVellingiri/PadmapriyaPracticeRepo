package LoopConditions;
import java.util.Scanner;

/*20.Using do–while, find whether a number is palindrome, but:
Exit loop early if mismatch is found
🔹 FOR LOOP (Advanced Logic)
 */

class A20
{
	static void run()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number : ");
		int num = sc.nextInt();
		int temp = num;
		int rev = 0;
	
		do
		{
			int digit = temp%10;
			rev = rev * 10 + digit;
			temp = temp/10;
		}while(temp > 0);
				
			if(num == rev)
			{
				System.out.println("Palindrome");
			}
			else
			{
				System.out.println("Not Palindrome");
			}
		}
}
		
public class Question20 {

	public static void main(String[] args) {
		A20.run();

	}

}
