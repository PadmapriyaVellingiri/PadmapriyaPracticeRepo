package LoopConditions;

/*
 21.Print all numbers between 1 and 500 that:
Have exactly 3 divisors
 */

class A21
{
	static void PrintNumbers()
	{
		System.out.println(" Numbers from 1 to 500 with exactly 3 divisors ");
		
		for(int num = 1; num <= 500; num++)
		{
			int count = 0;
			for(int i =1; i<= num;i++)
			{
				if (num %i == 0)
				{
					count ++;
				}
			}
			if (count == 3)
			{
				System.out.println(num);
			}
		}
		
	}
}

public class Question21 {

	public static void main(String[] args) {
	
		A21.PrintNumbers();

	}

}
