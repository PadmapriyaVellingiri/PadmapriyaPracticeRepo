package LoopConditions;

/*
 23.Print this pattern using nested for:
1
12
123
1234
12345
But skip printing 3 in all rows
 */

class A23
{
	static void display()
	{
		for(int i=1;i<=5 ;i++)
		{
			System.out.println("");
			for(int j=1;j<=i;j++)
			{
				if(j!=3)
				{
				System.out.print(j);
				}
			}
		}
	}
}

public class Question23 {

	public static void main(String[] args) {
		A23.display();

	}

}
