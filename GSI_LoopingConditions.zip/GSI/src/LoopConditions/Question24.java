package LoopConditions;

/*
 24.Using nested for, print:

5 4 3 2 1
4 3 2 1
3 2 1
2 1
1

But do NOT use subtraction operator (-)
 */

class A24
{
	static void display()
	{
		for(int i=5 ; i >=1 ; i--)
		{
			System.out.println(" ");
			for(int j=i; j>=1 ; j--)
			{
				System.out.print(j + " ");
			}
		}
	}
}

public class Question24 {

	public static void main(String[] args) {
		A24.display();

	}

}
