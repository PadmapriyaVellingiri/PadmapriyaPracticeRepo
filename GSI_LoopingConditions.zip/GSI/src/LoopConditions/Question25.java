package LoopConditions;


/*25.Write a program to print all perfect numbers between 1 and 10000 using:
Nested for
if condition only
 */

//perfect number means - sum of its divisors (except itself) = the number
/* suppose 6 - perfect number
 divisors of 6 is 1,2,3
 sum = 1+2+3=6
 so 6 is perfect number
 */

class A25
{
	static void display()
	{
		
		for(int i = 1; i<=10000; i++)
		{
			int sum =0;
			for(int j=1; j<i; j++)
			{
				if(i%j ==0)
				{
					sum = sum +j;
				}
			}
			if(sum==i)
			{
				System.out.println(i);
			}
		}
	}
}

public class Question25 {

	public static void main(String[] args) {
		A25.display();

	}

}
