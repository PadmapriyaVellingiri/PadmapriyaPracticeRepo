package LoopConditions;

import java.util.Scanner;

/*3.Write a program to check if a year is a leap year but:
take input as year and check whether it is leap or not?
 */

class A3
{
	static void leapYear()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter a year : ");
		int year = sc.nextInt();
		if(year % 4 == 0 && year % 100 !=0 )
		{
			System.out.println(year + "  is a leap year. ");
		}
		else
		{
			System.out.println(year + "  is not a leap year.");
		}
		sc.close();
	}
}

public class Question3 {

	public static void main(String[] args) 
	{
	
	A3.leapYear();	

	}

}
