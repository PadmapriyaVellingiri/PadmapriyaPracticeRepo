package LoopConditions;

import java.util.Scanner;

/*
 4.Input an integer and determine whether:
It is positive and divisible by 4
OR negative and divisible by 6
 */

class A4
{
	static void display() 
	{
		
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a value : ");
	int num = sc.nextInt();
	
	if(num>=0 && num%4 == 0)
	{
		System.out.println(" Number is positive and divisible by 4 : ");
	}
	else  if(num <0 && num%6 == 0)
	{
		System.out.println(" Number is negative and divisible by 6 : ");
	}
	else
	{
		System.out.println(" Value  is neither divisible by 4 or 6 .");
	}
	
	sc.close();
	}
}

public class Question4 {

	public static void main(String[] args) {
		
		A4.display();
	}

}
