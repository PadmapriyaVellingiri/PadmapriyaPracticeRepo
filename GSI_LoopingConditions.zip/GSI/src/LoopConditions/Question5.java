package LoopConditions;

import java.util.Scanner;

/*
 5.Write a program that prints:

"A" if number divisible by 2 and 3

"B" if divisible by 3 and not by 2

"C" if divisible by 2 and not by 3

"D" otherwise

ðŸ”¹ NESTED IFâ€“ELSE (Complex Conditions)

 */

class A5
{
	static void run()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter a number : ");
		int num = sc.nextInt();
		if (num%2 == 0)
		{
			if(num%3 == 0)
			{
				System.out.println(" A is divisible by 2 and 3");
			}
			else
			{
				System.out.println(" C is divisible by 2 and not by 3");
			}
		}
		else 
		{
			if(num%3 == 0)
			{
				System.out.println(" B is divisible by 3 and not by 2 ");
			}
			else
			{
				System.out.println(" D ");
			}
			
		}
		sc.close();
	}
}

public class Question5 {

	public static void main(String[] args) {
		
		A5.run();
	}

}
