package LoopConditions;

import java.util.Scanner;

/*
 6.Given marks in Math, Physics, Chemistry, determine eligibility:

Math â‰¥ 60

Physics â‰¥ 50

Chemistry â‰¥ 40
AND

Total â‰¥ 180 OR Math + Physics â‰¥ 120

 */

class A6
{
	static void eligibilityCheck()
	{
		Scanner sc = new Scanner(System.in);
		for(int i=1; i<= 3; i++)
		{
		System.out.println(" Enter marks for student :" + i);
		//System.out.println(" Enter student name :");
		//String name = sc.nextLine();
		System.out.println(" Enter maths mark :");
		int math = sc.nextInt();
		System.out.println(" Enter physics mark :");
		int phy = sc.nextInt();
		System.out.println(" Enter chemistry mark :");
		int che = sc.nextInt();
		
		int total = math + phy + che ;
		int sum = math + phy;
		
		if(math >= 60 && phy >= 50 && che >= 40)
		{
			if(total >= 180 || sum >= 120)
			{
				System.out.println("Student " + i + " is Eligible ! ");
				System.out.println("  ");
			}
		}
		else
		{
			System.out.println(" Student " + i + " is not Eligible !");	
			System.out.println("   ");
		}
		}
			sc.close();
	}
}

public class Question6 {

	public static void main(String[] args) {
		A6.eligibilityCheck();
		

	}

}
