package LoopConditions;

import java.util.Scanner;

/*
 7.

Write a program to find the largest of four numbers using:

Nested ifâ€“else only

No loops

No arrays
 */

class A7
{
	static void findLargest()
	{
		System.out.println("Largest Number");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number A : ");
		int a = sc.nextInt();
		System.out.println("Enter number B : ");
		int b = sc.nextInt();
		System.out.println("Enter number C : ");
		int c = sc.nextInt();
		System.out.println("Enter number D : ");
		int d = sc.nextInt();
		if(a>b && a>c && a>d)
		{
			System.out.println("A is largest");
		}
		else if(b>a && b>c && a>d)
		{
			System.out.println("B is largest");
		}
		else if(c>a && c>b && c>d)
		{
			System.out.println("C is largest");
		}
		else
		{
			System.out.println("D is largest");
		}
		sc.close();
				
	}
}

public class Question7 {

	public static void main(String[] args) {
		
		A7.findLargest();
	}

}
