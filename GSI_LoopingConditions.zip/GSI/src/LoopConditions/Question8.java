package LoopConditions;

import java.util.Scanner;

/*8.Given age and salary:

If age < 25 → Not eligible

If age ≥ 25 and salary < 30000 → Eligible for loan A

If age ≥ 30 and salary ≥ 50000 → Eligible for loan B
➡️ Use deep nested if
 */

class A8
{
	static void loanEligibility()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Age :");
		int age = sc.nextInt();
		System.out.println("Enter Salary :");
		int salary = sc.nextInt();
		if(age>=25 && salary < 30000)
		{
			System.out.println("Eligible for loan A");
		}
		else if(age>=30 && salary >= 50000)
		{
			System.out.println("Eligible for loan B");
		}
		else
		{
			System.out.println("Not Eligible");
		}
		sc.close();				
		
	}
}

public class Question8 {

	public static void main(String[] args) {
		A8.loanEligibility();

	}

}
