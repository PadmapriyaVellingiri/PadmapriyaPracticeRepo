package MyPackage;

/*
 5.  Abstraction using Abstract Class

Create an abstract class Animal with an abstract method sound().
Create two subclasses Dog and Cat and provide implementation for sound() method.
Create objects and call sound() for each.
 */

abstract class Animal
{
	abstract void sound();
}

class Dog extends Animal
{
	void sound()
	{
		System.out.println("Dog barks. ");
	}
}

class Cat extends Animal
{
	void sound()
	{
		System.out.println("Cat meow. ");
	}

}

public class Abstraction {

	public static void main(String[] args) {
		
		Dog d = new Dog();
		d.sound();
		
		Cat c = new Cat();
		c.sound();		
		
	}

}
