package MyPackage;

/*
 23.  Constructor Chaining

Create a class Mall with:

Default constructor printing "Welcome to the Mall"

Parameterized constructor calling default constructor using this()
Demonstrate constructor chaining in main.
 */

class Mall
{
	Mall()
	{
		System.out.println(" Welcome to the Mall");
	}
	Mall(String mallName)
	{
		this();
		System.out.println("Mall Name : " + mallName);
	}
	
}

public class ConstructorChaining {

	public static void main(String[] args) {
		
		Mall m = new Mall("Fun mall");

	}

}
