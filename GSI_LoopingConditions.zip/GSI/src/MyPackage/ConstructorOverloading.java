package MyPackage;

/*
 3. Constructor Overloading

Create a class Product having instance variables productId, productName, and price.
Implement:

A default constructor that prints "Product Created".

A parameterized constructor that initializes the product details.
Write a method displayProduct() to print product details.
Create both types of objects in the main method.

 */

class Product
{
	private int productId;
	private String productName;
	private int price;
	
	Product()
	{
		System.out.println("Product Created ");
	}
	
	Product(int x, String y, int z)
	{
		productId = x;
		productName = y;
		price = z;		
	}
	
	void displayProduct()
	{
		System.out.println(productId + "  " + productName + "   "+ price);
		
	}
}


public class ConstructorOverloading 
{
	public static void main(String[] args)
	{
		
		Product obj = new Product();
		//obj.displayProduct();
				
		Product obj1 = new Product(123, "Mobile", 25000);
		obj1.displayProduct();
		

	}

}
