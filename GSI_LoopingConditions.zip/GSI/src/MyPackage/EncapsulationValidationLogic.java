package MyPackage;

/*
 12.  Encapsulation + Validation Logic

Create a class Account with private variables accountHolderName and balance.
Provide setters and getters, where:

setBalance() should not accept negative values (print a warning).
Create an object and update values through setters only.

 */

class Account
{
	private String accountHolderName;
	private int balance;
	
	public String getAccountHolderName()
	{
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) 
	{
		this.accountHolderName = accountHolderName;
	}
	
	
	public int getBalance()
	{
		return balance;
	}
	public void setBalance(int balance) 
	{
		if (balance < 0) 
		{
		System.out.println("negative values are not accecptable. ");
		}
		else
		{
			this.balance = balance;
		}
	}
	
	void display()
	{

		System.out.println("Account holder name : " + accountHolderName);
		System.out.println("Account balance : "+ balance);
	}
}

public class EncapsulationValidationLogic {

	public static void main(String[] args) {
	
		Account acc = new Account();
		
		acc.setAccountHolderName("jhon");
		acc.setBalance(15);
		acc.setBalance(-15);
			
		acc.display();
		
		
		
	}

}
