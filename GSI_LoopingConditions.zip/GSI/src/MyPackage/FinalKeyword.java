package MyPackage;

/*
 9.  Final Keyword

Create a class Bank with a final variable IFSC and final method showIFSC().
Try creating a subclass HDFCBank and attempt overriding the final method (should show compile-time restriction).
Create a main method to demonstrate usage.

 */

class Bank
{
	final String IFSC = "HDFC1002";
	
	final void showIFSC()
	{
		System.out.println("IFSC = " + IFSC);
	}
}

class HDFCBank extends Bank
{
	 //cannot override final method = will get compile time error
	
	/*void showIFSC()
	{
		System.out.println("HDFC");
	}*/
}


public class FinalKeyword {

	public static void main(String[] args) {
		
		Bank obj = new Bank ();
		obj.showIFSC();
		
		HDFCBank obj1 = new HDFCBank();
		obj1.showIFSC();
		

	}

}
