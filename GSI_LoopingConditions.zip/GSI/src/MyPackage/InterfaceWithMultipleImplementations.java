package MyPackage;

/*
 18.  Interface with Multiple Implementations

Create an interface Transport with method booking().
Implement it in Bus and Flight classes.
Call using interface reference.

 */

interface Transport
{
	abstract void booking();
	
}

class Bus implements Transport
{

	@Override
	public void booking()
	{
	System.out.println("Bus ticket is booked");	
		
	}
	
}

class Flight implements Transport
{

	@Override
	public void booking()
	{
		System.out.println("Flight ticket is booked");
		
	}
	
}
public class InterfaceWithMultipleImplementations {

	public static void main(String[] args)
	{
		Transport ref = new Flight();
		ref.booking();
		
		Transport ref1 = new Bus();
		ref1.booking();
		
	}

}
