package MyPackage;

/*
 4. Method Overloading

Create a class Calculator with overloaded methods add():

add(int a, int b)

add(double a, double b)
Call both methods inside the main method and print results.
 */

class Calculator
{
	int add(int a, int b)
	{
		return a+b;
	}
	
	double add(double a, double b)
	{
		return a+b;
	}
	
}

public class MethodOverloading {

	public static void main(String[] args) {
		
		Calculator c = new Calculator();
		System.out.println(c.add(2, 3));

		Calculator c1 = new Calculator();
		System.out.println(c1.add(2.5d, 2.5d));
		
	}
		
}
