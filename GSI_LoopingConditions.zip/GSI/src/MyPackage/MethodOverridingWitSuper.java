package MyPackage;

/*
 16.  Method Overriding with super

Create a base class Hospital with a method emergencyService().
Create a subclass CityHospital that overrides the method and calls parent method using super.emergencyService().
Demonstrate overriding in main.

 */

class Hospital
{
	void emergencyService()
	{
		System.out.println("Hospital provides 24/7 emergency service");
	}
}

class CityHospital extends Hospital
{
	void emergencyService()
	{
		super.emergencyService();
		System.out.println("City hospital has advanced ICU unit");
	}
}

public class MethodOverridingWitSuper {

	public static void main(String[] args) {
		
		Hospital h = new CityHospital();
		
		h.emergencyService();
		

	}

}
