package MyPackage;

/*
 8.  Polymorphism (Dynamic Binding)

Create a parent class Shape with a method area().
Create subclasses Rectangle and Circle and override the area() method.
Create a reference of Shape and assign objects of both subclasses one by one, calling area() each time.

 */

class Shape
{
	void area()
	{
		System.out.println("Area ");
	}
}

class Rectangle extends Shape
{
	void area()
	{
		int l = 10;
		int b = 25;
		int rect = l * b;
		System.out.println("Area of rectangle is " + rect);
	}
}

class Circle extends Shape
{
	void area()
	{
		float pie = 3.14f;
		int r = 5;
		float circle = pie * r * r;
		System.out.println("Area of circle is " + circle);
	}
}

public class Polymorphism {

	public static void main(String[] args) {
		
		Shape ref = new Shape();
		ref.area();
		
		Shape ref1 = new Rectangle();
		ref1.area();
		
		Shape ref2 = new Circle();
		ref2.area();
			
	}

}
