package MyPackage;

/*
 24 >   WAP in Java 
Create a Class named Shape with length as instance variable  , create three methods as square , rectangle , circle 
and find out their respective areas 
Create a object in main method and call these different methods with the instance of object 
 */

class Shape1
{
	int length = 10;
	
	void square()
	{
		int a = 5;
		int area = a*a;
		System.out.println("Area of Square : " + area);
	}
	
	void rectangle(int b)
	{
		int rect = length*b;
		System.out.println("Area of rectangle : " + rect);
	}
	
	void circle(int r)
	{
		final double pie = 3.14;
		double circle;
		circle =  pie *r *r;
		System.out.println("Area of circle : " + circle);
	}
}
public class Question24 {

	public static void main(String[] args)
	{
	Shape1 obj = new Shape1();
	obj.square();
	obj.rectangle(5);
	obj.circle(9);

	}

}
